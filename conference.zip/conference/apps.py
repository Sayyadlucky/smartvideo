from django.apps import AppConfig


class AngularConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'conference'
